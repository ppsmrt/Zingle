import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { getAuth, RecaptchaVerifier, signInWithPhoneNumber } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { getFirestore, collection, addDoc, query, orderBy, onSnapshot, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";
import { encryptMessage, decryptMessage, generateKeyPair, exportPublicKey, importPublicKey } from './crypto.js';

const firebaseConfig = {
  apiKey: "AIzaSyCLUBxSL0nUC19cELEouO0p1t9dDPAWVQs",
  authDomain: "zinglechat.firebaseapp.com",
  projectId: "zinglechat",
  storageBucket: "zinglechat.firebasestorage.app",
  messagingSenderId: "1030280255471",
  appId: "1:1030280255471:web:90a7b6cc35678f3755c81a",
  measurementId: "G-FN3YELJ3K0"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

window.recaptchaVerifier = new RecaptchaVerifier('recaptcha-container', { size: 'invisible' }, auth);

const phoneInput = document.getElementById('phone-number');
const sendOtpBtn = document.getElementById('send-otp');
const otpInput = document.getElementById('otp-code');
const verifyBtn = document.getElementById('verify-otp');
const chatScreen = document.getElementById('chat-screen');
const loginScreen = document.getElementById('login-screen');
const sendBtn = document.getElementById('send-btn');
const chatWindow = document.getElementById('chat-window');
const messageInput = document.getElementById('message-input');

let confirmationResult;
let currentUserPhone = "";

sendOtpBtn.onclick = async () => {
  const phoneNumber = phoneInput.value;
  confirmationResult = await signInWithPhoneNumber(auth, phoneNumber, window.recaptchaVerifier);
  otpInput.style.display = 'block';
  verifyBtn.style.display = 'block';
};

verifyBtn.onclick = async () => {
  const code = otpInput.value;
  const result = await confirmationResult.confirm(code);
  currentUserPhone = result.user.phoneNumber;
  loginScreen.style.display = 'none';
  chatScreen.style.display = 'block';
  listenForMessages();
};

sendBtn.onclick = async () => {
  const text = messageInput.value;
  const encrypted = await encryptMessage(text);
  await addDoc(collection(db, "messages"), {
    sender: currentUserPhone,
    encrypted,
    timestamp: serverTimestamp()
  });
  messageInput.value = "";
};

function listenForMessages() {
  const q = query(collection(db, "messages"), orderBy("timestamp"));
  onSnapshot(q, async (snapshot) => {
    chatWindow.innerHTML = "";
    for (let doc of snapshot.docs) {
      const data = doc.data();
      const msg = await decryptMessage(data.encrypted);
      const div = document.createElement('div');
      div.className = "message " + (data.sender === currentUserPhone ? "sent" : "received");
      div.textContent = msg;
      chatWindow.appendChild(div);
    }
  });
}