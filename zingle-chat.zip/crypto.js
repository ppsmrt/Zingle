// Simplified encryption using Web Crypto (for demo purposes only)

const enc = new TextEncoder();
const dec = new TextDecoder();
let key = null;

async function generateKey() {
  key = await window.crypto.subtle.generateKey(
    { name: "AES-GCM", length: 256 },
    true,
    ["encrypt", "decrypt"]
  );
}

generateKey();

export async function encryptMessage(message) {
  const iv = window.crypto.getRandomValues(new Uint8Array(12));
  const encoded = enc.encode(message);
  const ciphertext = await window.crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    encoded
  );
  return {
    iv: Array.from(iv),
    data: Array.from(new Uint8Array(ciphertext))
  };
}

export async function decryptMessage({ iv, data }) {
  const buffer = new Uint8Array(data);
  const plaintext = await window.crypto.subtle.decrypt(
    { name: "AES-GCM", iv: new Uint8Array(iv) },
    key,
    buffer
  );
  return dec.decode(plaintext);
}